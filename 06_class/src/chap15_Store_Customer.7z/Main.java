package chap15_Store_Customer;

public class Main {

  public static void main(String[] args) {
    
    //----- 한 명의 고객을 생성합니다.
    
    //----- 상품을 판매할 두 개의 상점을 생성합니다.
    
    //----- 첫 번째 상점에서 상품을 구매합니다. 
    
    //----- 두 번째 상점에서 상품을 구매합니다.
    
    //----- 모든 상점의 정보와 고객의 정보를 출력합니다.

  }

}
