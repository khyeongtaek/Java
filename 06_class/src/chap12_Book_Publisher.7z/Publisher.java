package chap12_Book_Publisher;

// 문제. 생성자 없이 Getter/Setter를 생성하세요.

public class Publisher {

  private String name;  //------ 출판사이름
  private String location;  //-- 출판사위치
  private Contact contact;  //-- 출판사연락처
  
}
