package chap03_ex;

public class Ex09 {

  public static void main(String[] args) {
    
    // 2단부터 9단까지 구구단을 2차원 배열에 저장하세요.
    
    /*
        gugudan[0][0] = "2x1=(2*1)"
        gugudan[0][1] = "2x2=(2*2)"
        gugudan[0][2] = "2x3=(2*3)"
        ...
        gugudan[1][0] = "3x1=(3*1)"
        gugudan[1][1] = "3x1=(3*1)"
        gugudan[1][2] = "3x1=(3*1)"
        ...
        ---------------------
        gugudan[i][j] = "(i+2)x(j+1)=((i+2)*(j+1))"
    */
    
    String[][] gugudan = new String[8][9];
    
  }
  
}
